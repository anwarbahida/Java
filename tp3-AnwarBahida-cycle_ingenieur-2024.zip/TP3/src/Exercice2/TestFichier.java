package Exercice2;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class TestFichier {
    
	private File fichier;
	
	// Constructeur avec un nom de fichier
    public TestFichier(String nomFichier) {
        this.fichier = new File(nomFichier);
    }

    // Constructeur avec un objet File
    public TestFichier(File fichier) {
        this.fichier = fichier;
    }

    // Méthode pour ajouter du texte au fichier
    public void modifier(String txt) {
        try (FileWriter writer = new FileWriter(fichier, true)) {
            writer.write(txt);
            writer.write(System.lineSeparator());
            System.out.println("Texte ajouté au fichier.");
        } catch (IOException e) {
            System.out.println("Erreur lors de la modification du fichier : " + e.getMessage());
        }
    }

    // Méthode pour afficher le contenu du fichier
    public void afficher() {
        try (FileReader reader = new FileReader(fichier)) {
            int caractere;
            while ((caractere = reader.read()) != -1) {
                System.out.print((char) caractere);
            }
            System.out.println(); // Saut de ligne après l'affichage
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
        }
    }

    // Méthode pour copier le fichier vers une nouvelle adresse
    public void copierColler(String adresse) {
        File fichiercp = new File(adresse);
        try {
            Files.copy(fichier.toPath(), fichiercp.toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Fichier copié avec succès.");
        } catch (IOException e) {
            System.out.println("Erreur lors de la copie du fichier : " + e.getMessage());
        }
    }

}
