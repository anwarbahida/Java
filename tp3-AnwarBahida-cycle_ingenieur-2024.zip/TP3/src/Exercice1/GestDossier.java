package Exercice1;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
public class GestDossier {
    
	private String Dossier;
	
	public GestDossier() {
		this.Dossier="C:\\";
	}
	public GestDossier(String Dossier) {
		this.Dossier=Dossier;
	}

	public String getDossier() {
		return this.Dossier;
	}

	public void setDossier(String dossier) {
		this.Dossier = dossier;
	}
	public void list() {
		SimpleDateFormat date=new SimpleDateFormat("dd-MM-YYYY hh-mm-ss");
		File doss=new File(getDossier());
		File[] contenu=doss.listFiles();
		for (File fich : contenu) {
			if(fich.isDirectory()) {
				System.out.println( fich.getName()+" <DOSS> " +date.format(fich.lastModified())+" Taille : "+fich.length());
			}
			if(fich.isFile()) {
				System.out.println( fich.getName()+" <FICH> "+date.format(fich.lastModified())+" Taille : "+fich.length());
				
			}
		}
	}
	
	public void creeFichier(String nomfichier) throws IOException {
		
		File fichier = new File(this.Dossier,nomfichier);
		if (fichier.exists()) {
			System.out.println("ce Fichier est deja existe !!!");
		}
		else {
			fichier.createNewFile();
		}
	}
    public void creeDossier(String sous_dossier) {
    	File Dossier = new File(this.Dossier,sous_dossier);
		if (Dossier.exists()) {
			System.out.println("ce Fichier est deja existe !!!");
		}
		else {
			Dossier.mkdir();
		}
    }
    public void suppimer(String element) {
    	File Dossier = new File(this.Dossier,element);
    	if (!Dossier.exists()) {
			System.out.println("ce Fichier est n'existe pas !!!");
		}
		else {
			Dossier.delete();
		}
    }

}
