package Exercice1;
import java.io.IOException;
import Exercice2.TestFichier;

public class Principale {

	public static void main(String[] args) throws IOException {
		
		System.out.println("\n:::::::::::::::::::::::::::::Exercice 1:::::::::::::::::::::::::::::::::\n"
		                   + "////////////////////////////////////////////////////////////////////////");
		
		GestDossier Doss= new GestDossier("C:\\Users\\HP\\Desktop\\TpJava\\TP3\\src\\Exercice1");
		Doss.creeFichier("Anwar.txt");
		Doss.creeFichier("Anwar.java");
		Doss.creeFichier("Anwar.docx");
		Doss.creeDossier("TPJAVA");
		Doss.suppimer("Anwar.java");
		Doss.list();
		
		System.out.println("\n:::::::::::::::::::::::::::::Exercice 2:::::::::::::::::::::::::::::::::\n"
				          +  "////////////////////////////////////////////////////////////////////////");
        TestFichier fichierTest = new TestFichier("Fichier.txt");
        
        // Ajouter du texte au fichier
        fichierTest.modifier("Cycle d'ingénieur en génie informatique 2024/2025 .");
        
        // Afficher le contenu du fichier
        fichierTest.afficher();
        
        // Copier le fichier vers une nouvelle destination
        fichierTest.copierColler("Fichier1.txt");
		
		
		
		
	}

}
