package Exercice8;

import java.util.Date;
import java.util.Calendar;

public class Etudiant implements Personne {
	
    private String nom;
    private String prenom;
    private Date date_naiss;
    private String CNE;

    // Constructeur par défaut
    public Etudiant() {
    }

    // Constructeur avec arguments
    public Etudiant(String nom, String prenom, String CNE, Date date_naiss) {
        this.nom = nom;
        this.prenom = prenom;
        this.CNE = CNE;
        this.date_naiss = date_naiss;
    }

    // Getters et Setters
    @Override
    public String getNom() {
        return nom;
    }

    @Override
    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public String getPrenom() {
        return prenom;
    }

    @Override
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    @Override
    public Date getDateNais() {
        return date_naiss;
    }

    @Override
    public void setDateNais(Date date_naiss) {
        this.date_naiss = date_naiss;
    }

    public String getCNE() {
        return CNE;
    }

    public void setCNE(String CNE) {
        this.CNE = CNE;
    }

    // Implémentation des méthodes de l'interface
    @Override
    public double calculerAge() {
       
        Calendar today = Calendar.getInstance();
        Calendar birthDate = Calendar.getInstance();
        birthDate.setTime(date_naiss);
        int age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);
        if (today.get(Calendar.DAY_OF_YEAR) < birthDate.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        return age;
    }

    @Override
    public boolean estFrereDe(Personne autrePersonne) {
        return this.nom.equals(autrePersonne.getNom());
    }
}

