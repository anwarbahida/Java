package Exercice8;

import java.util.Date;

public interface Personne {
    String getNom();
    void setNom(String nom);

    String getPrenom();
    void setPrenom(String prenom);

    Date getDateNais();
    void setDateNais(Date date_naiss);

    double calculerAge();
    boolean estFrereDe(Personne autrePersonne);
}
