package Exercice7;

abstract public class Forme {
    
	private double x;
	private double y;
	
	public Forme(){
		this.x=0;
		this.y=0;
	}
	
	public Forme(double x,double y) {
		this.x=x;
		this.y=y;
	}


	public void setX(double a) {
		this.x=a;
	}
	public void setY(double b) {
		this.y=b;
	}
	public double getX() {
		return this.x;
	}
	public double getY() {
		return this.y;
	}
	public void deplacer(double dx,double dy) {
		this.x+=dx;
		this.y+=dy;
	}
	abstract double surface();
	abstract double perimetre();

}
