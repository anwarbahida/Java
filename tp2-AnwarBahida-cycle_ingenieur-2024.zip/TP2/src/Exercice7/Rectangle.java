package Exercice7;

public class Rectangle extends Forme {
	
    private double longeur;
    private double largeur;
    
	public Rectangle() {
		super(0,0);
		this.longeur=0;
		this.largeur=0;
	}
	public Rectangle(double x,double y , double longeur,double largeur) {
		super(x,y);
		this.longeur=longeur;
		this.largeur=largeur;
	}
	public double getLargeur() {
		return this.largeur;
	}
	
	public double getLongeur() {
		return this.longeur;
	}
	
	public void setLongueur(double longeur) {
        this.longeur = longeur;
    }

    public void setLargeur(double largeur) {
        this.largeur = largeur;
    }
	
    @Override
    public double surface() {
    	return this.longeur*this.largeur;
    }
    @Override
    public double perimetre() {
    	return 2 * (this.longeur + this.largeur) ;
    }
    public String toString() {
    	System.out.println("le Centre de Rectangle est : ("+getX()+","+getY()+")");
    	System.out.println("longeur de Rectangle : "+this.longeur+"\nlargeur de Rectangle : "+this.largeur);
		return null;
    }
	    

}
