package Exercice7;
import java.util.ArrayList;
public class Principale {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Forme form1 ;
		Cercle cercle1=new Cercle(5,4,3.5);
		cercle1.setRayon(10);
		cercle1.toString();
		
		Rectangle rectangle1 = new Rectangle(5,4,8,7);
		rectangle1.deplacer(2.5, 3.5);
		rectangle1.toString();
		rectangle1.setLongueur(8);
		rectangle1.setLargeur(9);
		rectangle1.deplacer(2.5,3.5);
		rectangle1.toString();
		System.out.println("Lea surface de rectangle : "+rectangle1.surface());
		
		//cercle1= rectangle1;
		//rectangle1 =cercle1;
		//rectangle1 =form1;
		//cercle1 =form1;
		form1=rectangle1;
		form1=cercle1;
		
		ArrayList<Forme> formes = new ArrayList<>();
        // Ajouter deux rectangles à la liste
        formes.add(new Rectangle(0, 0, 10, 5));
        formes.add(new Rectangle(0, 0, 20, 15));

        // Ajouter deux cercles à la liste
        formes.add(new Cercle(0, 0, 5));
        formes.add(new Cercle(0, 0, 10));

        // Parcourir la liste et afficher la surface de chaque forme
        for (Forme forme : formes) {
        	
	        String typeForme;
	        if (forme instanceof Rectangle) {
	            typeForme = "Rectangle";
	        } else{
	            typeForme = "Cercle";
	        } 
	        // Afficher le type de la forme et sa surface
	        System.out.println("Type de forme : " + typeForme + ", Surface : " + forme.surface());
        }
	}

}
