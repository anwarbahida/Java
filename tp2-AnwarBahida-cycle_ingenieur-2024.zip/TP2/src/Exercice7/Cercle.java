package Exercice7;

public class Cercle extends Forme {
    private double rayon;
    
	public Cercle() {
		super(0,0);
		this.rayon=0;
	}
	public Cercle(double x,double y,double rayon) {
		super(x,y);
		this.rayon=rayon;
	}
	public void setRayon(double rayon) {
		this.rayon=rayon;
	}
	public double getRayon() {
		return this.rayon;
	}
    @Override
    public double surface() {
    	return Math.PI * Math.pow(rayon, 2);
    }
    @Override
    public double perimetre() {
    	return 2 * Math.PI * rayon ;
    }
    
    public String toString() {
    	System.out.println("le centre de cercle est : ("+getX()+","+getY()+")");
    	System.out.println("Rayon de cercle : "+getRayon());
    	return null;
    }
    
} 
