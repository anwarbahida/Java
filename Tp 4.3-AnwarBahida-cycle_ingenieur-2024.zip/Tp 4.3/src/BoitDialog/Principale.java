package BoitDialog;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

public class Principale implements ActionListener {

    JFrame fen;
    JPanel panel;
    JButton BtnHeur;
    JButton BtnAuthentifiction;
    JLabel lblLogin, lblPassword;
    JTextField txtLogin;
    JPasswordField txtPassword;

    public Principale() {
        // Création de la fenêtre
        fen = new JFrame();
        fen.setTitle("Test des barres et conteneurs");
        fen.setSize(700, 500);
        fen.setResizable(false);
        fen.setLocationRelativeTo(null);
        fen.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        // Création du panneau principal
        panel = new JPanel();
        panel.setLayout(null);

        // Bouton "Quelle heure est-il"
        BtnHeur = new JButton("Quelle Heure est-il");
        BtnHeur.setBounds(260, 60, 150, 40);
        BtnHeur.addActionListener(this);
        BtnHeur.setBackground(Color.cyan);
        panel.add(BtnHeur);

        // Label et champ de saisie pour le login
        lblLogin = new JLabel("Login");
        lblLogin.setBounds(200, 150, 100, 30);
        panel.add(lblLogin);

        txtLogin = new JTextField();
        txtLogin.setBounds(300, 150, 200, 30);
        panel.add(txtLogin);

        // Label et champ de saisie pour le mot de passe
        lblPassword = new JLabel("Password");
        lblPassword.setBounds(200, 210, 100, 30);
        panel.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(300, 210, 200, 30);
        panel.add(txtPassword);

        // Bouton "Test Authentification"
        BtnAuthentifiction = new JButton("Test Authentification");
        BtnAuthentifiction.setBounds(260, 300, 170, 40);
        BtnAuthentifiction.addActionListener(this);
        BtnAuthentifiction.setBackground(Color.cyan);
        panel.add(BtnAuthentifiction);

        // Ajouter le panneau principal à la fenêtre
        fen.add(panel);

        // Gestion de la fermeture avec confirmation
        fen.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int choix = JOptionPane.showConfirmDialog(
                    fen,
                    "Voulez-vous vraiment quitter ?",
                    "Confirmation",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );

                if (choix == JOptionPane.YES_OPTION) {
                	JOptionPane.showMessageDialog(fen, "OK==Merci", "", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
                }
            	    JOptionPane.showMessageDialog(fen, "Vous avez Annuler ", "", 2);

            }
        });

        // Afficher la fenêtre
        fen.setVisible(true);
    }

    public static void main(String[] args) {
        new Principale();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == BtnHeur) {
            JOptionPane.showMessageDialog(fen, "8 h 30 mm", "Message", JOptionPane.INFORMATION_MESSAGE);
        } else if (e.getSource() == BtnAuthentifiction) {
            String login = txtLogin.getText();
            char[] passwordArray = txtPassword.getPassword();
            String password = new String(passwordArray).trim();

            if (login.equals("Anwar") && password.equals("Anwar123")) {
                JOptionPane.showMessageDialog(fen, "Authentification Réussie", "Succès", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(fen, "Erreur de Login ou Mot de Passe", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
