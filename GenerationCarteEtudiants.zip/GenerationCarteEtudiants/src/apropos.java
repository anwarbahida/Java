import javax.swing.*;
import java.awt.*;

public class apropos {

    private JMenuItem apro;

    public apropos(JFrame parentFrame) {
    	
        apro = new JMenuItem("À propos");
        apro.addActionListener(e -> {
        	
            // Créer un JPanel principal
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout(15, 15));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espacement

            // Ajout de l'image redimensionnée
            JLabel imageLabel = new JLabel();
            ImageIcon originalIcon = new ImageIcon("images/ph.jpg"); // Chemin de l'image

            try {
                // Redimensionner l'image si elle existe
                Image originalImage = originalIcon.getImage();
                Image resizedImage = originalImage.getScaledInstance(400, 200, Image.SCALE_SMOOTH);
                ImageIcon resizedIcon = new ImageIcon(resizedImage);
                imageLabel.setIcon(resizedIcon);
            } catch (Exception ex) {
                imageLabel.setText("Image introuvable");
                imageLabel.setHorizontalAlignment(JLabel.CENTER);
            }
            panel.add(imageLabel, BorderLayout.WEST);

            // Ajout des informations textuelles
            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);
            textArea.setText("""
            		
                Version :
                      + 1.0
                Réalisé par :
                      + Ayoub Addichane
                      + Anwar Bahida
                Parcours :
                      + Cycle d'ingénieur en Génie Informatique(S3)
                      + 2024/2025
                Encadrant :
                      + Mourad Azrour
                """);

            // Configurer la police et les couleurs
            textArea.setFont(new Font("Consolas", Font.PLAIN, 16));
            textArea.setForeground(Color.DARK_GRAY);
            textArea.setBackground(panel.getBackground());
            textArea.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
            panel.add(textArea, BorderLayout.CENTER);

            // Ajout d'un titre dans un JLabel
            JLabel titleLabel = new JLabel("À propos de l'application");
            titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
            titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
            titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));
            panel.add(titleLabel, BorderLayout.NORTH);

            // Afficher le panneau dans un JOptionPane
            JOptionPane.showMessageDialog(parentFrame, panel, "À propos", JOptionPane.INFORMATION_MESSAGE);
        });
    }

    public JMenuItem getMenuItem() {
        return apro;
    }
}
