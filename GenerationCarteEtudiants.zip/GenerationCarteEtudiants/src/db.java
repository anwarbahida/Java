import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db {
	
    public static Connection getConnection() {
       

        Connection connection = null;

        try {
           
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            String url = "jdbc:mysql://localhost:3306/generer_carte_java"; 
            String username = "root"; 
            String password = "";
           
            connection = DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException e) {
            System.out.println("Pilote JDBC introuvable !");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Erreur lors de la connexion à la base de données !");
            e.printStackTrace();
        } 
        return connection;
    }
}
