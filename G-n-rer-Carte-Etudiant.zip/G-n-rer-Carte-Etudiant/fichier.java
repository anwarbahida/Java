

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import javax.swing.JOptionPane;

public class fichier {

    //Chemin complet vers le répertoire
    String fich = "AnneUniv";

    public int setAnneeUni(String annee) {
        try {
            // Vérifier que l'année est dans le format attendu "2024/2025"
            if (!annee.matches("\\d{4}/\\d{4}")) {
              return 1;
            }
            
            String[] annees = annee.split("/");
            int annee1 = Integer.parseInt(annees[0].trim());
            int annee2 = Integer.parseInt(annees[1].trim());
            if (annee2-annee1 != 1) {
            	return 2;
            }
            
            //Créer un objet File représentant le fichier
            File fi = new File(fich);



            // Écrire dans le fichier
            try (Writer w = new FileWriter(fi)) {
                w.write(annee);
            }
        } catch (IOException e) {
            System.err.println("Erreur: " + e.getMessage());
        }
		return 0;
    }

    public String afficherAnne() {
        String ligne = null;
        //Utiliser File pour garantir un chemin correct
        File fi = new File(fich);
        try (BufferedReader lir = new BufferedReader(new FileReader(fi))) {
            ligne = lir.readLine();// Lire la première ligne du fichier
        } catch (IOException e) {
            System.err.println("Erreur: " + e.getMessage());
        }
        return ligne;
    }
}