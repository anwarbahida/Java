import javax.swing.*;
import java.awt.*;

public class apropos {

    private JMenuItem apro;

    public apropos(JFrame parentFrame) {
        apro = new JMenuItem("A propos");
        apro.addActionListener(e -> {
            // Créer un JPanel pour contenir les informations
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout(10, 10));

            // Ajout d'une image redimensionnée
            JLabel imageLabel = new JLabel();
            ImageIcon originalIcon = new ImageIcon("images/ph.jpg"); // Chemin de l'image originale

            // Redimensionner l'image à 500x300
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(500, 300, Image.SCALE_SMOOTH); // Utilisation de SCALE_SMOOTH pour une meilleure qualité
            ImageIcon resizedIcon = new ImageIcon(resizedImage);

            imageLabel.setIcon(resizedIcon);
            panel.add(imageLabel, BorderLayout.WEST);

            // Ajout des informations textuelles
            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);
            textArea.setText("""
            		
            		
            		
                Version :
                      + 1.0
                Réalisé par : 
                      + Ayoub Addichane 
                      + Anwar Bahida
                Parcours :
                      + Cycle d'ingénieur en Génie Informatique 
                      + S3
                      + 2024/2025
                """);

            // Configurer la police en gras, Consolas, taille 18
            textArea.setFont(new Font("Consolas", Font.BOLD, 18));
            textArea.setBackground(panel.getBackground()); // Fond transparent

            panel.add(textArea, BorderLayout.CENTER);

            // Affichage dans un JOptionPane
            JOptionPane.showMessageDialog(parentFrame, panel, "À propos", JOptionPane.INFORMATION_MESSAGE);
        });
    }

    public JMenuItem getMenuItem() {
        return apro;
    }
}
