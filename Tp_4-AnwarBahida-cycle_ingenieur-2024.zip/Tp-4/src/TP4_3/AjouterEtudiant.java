package TP4_3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AjouterEtudiant extends JFrame {

    // Déclaration des champs de formulaire
    JPanel panel;
    private JTextField txtCNE, txtNom, txtPrenom, txtDateNaissance, txtEmail;
    private JPasswordField txtMotDePasse;
    private JRadioButton rbHomme, rbFemme;
    private JComboBox<String> cbPays;
    private JCheckBox cbLicence, cbMaster, cbDoctorat;
    private JLabel lblPhoto, lblApercuPhoto, lblCheminPhoto; // Déclaration des labels
    private File selectedPhoto;

    public AjouterEtudiant() {

        // Création du panneau principal
        panel = new JPanel();
        panel.setLayout(null);

        // Champs du formulaire

        // Titre
        JLabel lblTitre = new JLabel("Ajout d'un Etudiant", SwingConstants.CENTER);
        lblTitre.setBounds(0, 0, 900, 35);
        lblTitre.setOpaque(true); // Permet de définir un fond
        lblTitre.setBackground(Color.GREEN); // Couleur de fond en vert
        lblTitre.setForeground(Color.WHITE); // Couleur du texte en blanc (facultatif pour le contraste)
        lblTitre.setFont(new Font("Consolas", Font.BOLD, 20)); // Police en gras et taille 20
        panel.add(lblTitre);

        // **CNE**
        JLabel lblCNE = new JLabel("CNE :");
        lblCNE.setBounds(30, 50, 100, 35);
        panel.add(lblCNE);

        txtCNE = new JTextField();
        txtCNE.setBounds(150, 50, 200, 25);
        panel.add(txtCNE);

        // **Nom**
        JLabel lblNom = new JLabel("Nom :");
        lblNom.setBounds(30, 90, 100, 25);
        panel.add(lblNom);

        txtNom = new JTextField();
        txtNom.setBounds(150, 90, 200, 25);
        panel.add(txtNom);

        // **Prénom**
        JLabel lblPrenom = new JLabel("Prénom :");
        lblPrenom.setBounds(30, 130, 100, 25);
        panel.add(lblPrenom);

        txtPrenom = new JTextField();
        txtPrenom.setBounds(150, 130, 200, 25);
        panel.add(txtPrenom);

        // **Date de Naissance**
        JLabel lblDateNaissance = new JLabel("Date de Naissance :");
        lblDateNaissance.setBounds(30, 170, 120, 25);
        panel.add(lblDateNaissance);

        txtDateNaissance = new JTextField();
        txtDateNaissance.setBounds(150, 170, 200, 25);
        panel.add(txtDateNaissance);

        // **Email**
        JLabel lblEmail = new JLabel("Email :");
        lblEmail.setBounds(30, 210, 100, 25);
        panel.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(150, 210, 200, 25);
        panel.add(txtEmail);

        // **Mot de Passe**
        JLabel lblMotDePasse = new JLabel("Mot de Passe :");
        lblMotDePasse.setBounds(30, 250, 100, 25);
        panel.add(lblMotDePasse);

        txtMotDePasse = new JPasswordField();
        txtMotDePasse.setBounds(150, 250, 200, 25);
        panel.add(txtMotDePasse);

        // **Genre**
        JLabel lblGenre = new JLabel("Genre :");
        lblGenre.setBounds(30, 290, 100, 25);
        panel.add(lblGenre);

        rbHomme = new JRadioButton("Homme");
        rbHomme.setBounds(150, 290, 80, 25);

        rbFemme = new JRadioButton("Femme");
        rbFemme.setBounds(240, 290, 80, 25);

        ButtonGroup groupGenre = new ButtonGroup();
        groupGenre.add(rbHomme);
        groupGenre.add(rbFemme);

        panel.add(rbHomme);
        panel.add(rbFemme);

        // **Pays**
        JLabel lblPays = new JLabel("Pays :");
        lblPays.setBounds(30, 330, 100, 25);
        panel.add(lblPays);

        cbPays = new JComboBox<>(new String[]{"Maroc", "France", "Canada", "USA"});
        cbPays.setBounds(150, 330, 200, 25);
        panel.add(cbPays);

        // **Diplômes**
        JLabel lblDiplomes = new JLabel("Diplômes :");
        lblDiplomes.setBounds(30, 370, 100, 25);
        panel.add(lblDiplomes);

        cbLicence = new JCheckBox("Licence");
        cbLicence.setBounds(150, 370, 80, 25);

        cbMaster = new JCheckBox("Master");
        cbMaster.setBounds(240, 370, 80, 25);

        cbDoctorat = new JCheckBox("Doctorat");
        cbDoctorat.setBounds(330, 370, 100, 25);

        panel.add(cbLicence);
        panel.add(cbMaster);
        panel.add(cbDoctorat);

        // **Photo**
        JLabel lblPhotoText = new JLabel("Photo :");
        lblPhotoText.setBounds(30, 410, 100, 25);
        panel.add(lblPhotoText);

        JButton btnChoisirPhoto = new JButton("Choisir Photo");
        btnChoisirPhoto.setBounds(150, 410, 150, 25);
        btnChoisirPhoto.setBackground(new Color(10, 130, 160));
        btnChoisirPhoto.setForeground(Color.WHITE);
        panel.add(btnChoisirPhoto);

        // Ajout de l'écouteur pour le bouton
        btnChoisirPhoto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                choisirPhoto();
            }
        });

        // Initialisation du label pour afficher le chemin de la photo
        lblCheminPhoto = new JLabel("Aucun fichier choisi");
        lblCheminPhoto.setBounds(563, 410, 500, 25);
        panel.add(lblCheminPhoto);

        // Initialisation du label pour afficher l'aperçu de la photo
        lblApercuPhoto = new JLabel();
        lblApercuPhoto.setBounds(500, 50, 250, 250); // Taille de l'image affichée
        lblApercuPhoto.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // Bordure pour l'aperçu
        panel.add(lblApercuPhoto);

        // **Boutons Enregistrer et Effacer**
        JButton btnEffacer = new JButton("Effacer");
        btnEffacer.setBounds(130, 500, 100, 30);
        btnEffacer.setBackground(new Color(10, 130, 160));
        btnEffacer.setForeground(Color.WHITE);
        panel.add(btnEffacer);

        btnEffacer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                effacerChamps();
            }
        });

        JButton btnEnregistrer = new JButton("Enregistrer");
        btnEnregistrer.setBounds(300, 500, 120, 30);
        btnEnregistrer.setBackground(new Color(10, 130, 160));
        btnEnregistrer.setForeground(Color.WHITE);
        panel.add(btnEnregistrer);
        
        btnEnregistrer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	enregistrerDonnees();
            }
        });

        // Ajout du panneau principal à la fenêtre
    }

    // Méthode pour choisir une photo
    private void choisirPhoto() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images", "jpg", "jpeg", "png", "gif", "tiff"));
        int option = fileChooser.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            selectedPhoto = fileChooser.getSelectedFile();

            // Afficher le chemin de la photo
            lblCheminPhoto.setText(selectedPhoto.getAbsolutePath());

            // Afficher l'aperçu de la photo
            ImageIcon imageIcon = new ImageIcon(new ImageIcon(selectedPhoto.getAbsolutePath())
                    .getImage()
                    .getScaledInstance(250, 250, Image.SCALE_SMOOTH));
            lblApercuPhoto.setIcon(imageIcon);
        }
    }

    // Méthode pour effacer tous les champs
    private void effacerChamps() {
        txtCNE.setText("");
        txtNom.setText("");
        txtPrenom.setText("");
        txtDateNaissance.setText("");
        txtEmail.setText("");
        txtMotDePasse.setText("");
        rbHomme.setSelected(false);
        rbFemme.setSelected(false);
        cbPays.setSelectedIndex(0);
        cbLicence.setSelected(false);
        cbMaster.setSelected(false);
        cbDoctorat.setSelected(false);
        lblCheminPhoto.setText("Aucun fichier choisi"); // Efface le texte du label
        lblApercuPhoto.setIcon(null); // Efface l'image du label (si une image est affichée)
        
    }

    // Méthode pour enregistrer les données
    private void enregistrerDonnees() {
        String cne = txtCNE.getText();
        String nom = txtNom.getText();
        String prenom = txtPrenom.getText();
        String dateNaissance = txtDateNaissance.getText();
        String email = txtEmail.getText();
        String motDePasse = new String(txtMotDePasse.getPassword());
        String genre = rbHomme.isSelected() ? "Homme" : (rbFemme.isSelected() ? "Femme" : "Non spécifié");
        String pays = cbPays.getSelectedItem().toString();
        String diplomes = "";
        diplomes += cbLicence.isSelected() ? "Licence " : "";
        diplomes += cbMaster.isSelected() ? "Master " : "";
        diplomes += cbDoctorat.isSelected() ? "Doctorat" : "";
        if (cne.isEmpty() || nom.isEmpty() || prenom.isEmpty() || dateNaissance == null || email.isEmpty() || 
        	    genre == null || pays.isEmpty() || diplomes.isEmpty() || selectedPhoto == null) {
        	JOptionPane.showMessageDialog(this, "Remplir Tous les Champs");
        }
        else {
        
	        // Afficher un message avec les données (enlever cela si vous préférez enregistrer directement)
	        JOptionPane.showMessageDialog(this, "CNE: " + cne + "\nNom: " + nom + "\nPrénom: " + prenom +
	                "\nDate de Naissance: " + dateNaissance + "\nEmail: " + email + "\nGenre: " + genre +
	                "\nPays: " + pays + "\nDiplômes: " + diplomes + "\nPhoto: " + (selectedPhoto != null ? selectedPhoto.getPath() : "Aucune"));
	        
	        // Connexion à la base de données et insertion
	        try {
	            // Charger le driver MySQL
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            
	            // Créer la connexion à la base de données
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbgestion","root", "");
	                    
	
	            // Requête d'insertion SQL
	            String sql = "INSERT INTO etudiants (CNE, nom, prenom, date_naissance, email, mot_de_passe, genre, pays, diplomes, photo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
	            // Préparer la requête
	            PreparedStatement statement = connection.prepareStatement(sql);
	
	            // Remplir les paramètres de la requête avec les valeurs des champs
	            statement.setString(1, cne);
	            statement.setString(2, nom);
	            statement.setString(3, prenom);
	            statement.setString(4, dateNaissance);
	            statement.setString(5, email);
	            statement.setString(6, motDePasse);
	            statement.setString(7, genre);
	            statement.setString(8, pays);
	            statement.setString(9, diplomes);
	            statement.setString(10, selectedPhoto != null ? selectedPhoto.getPath() : null);
	
	            // Exécuter la requête
	            int rowsInserted = statement.executeUpdate();
	
	            if (rowsInserted > 0) {
	                JOptionPane.showMessageDialog(this, "L'étudiant a été ajouté avec succès !");
	            }
	
	            // Fermer la connexion à la base de données
	            statement.close();
	            connection.close();
	        
	        } catch (ClassNotFoundException | SQLException ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(this, "Erreur lors de l'enregistrement dans la base de données : " + ex.getMessage());
	        }
        }
    }

    public JPanel getPanel() {
        return panel;
    }
}
