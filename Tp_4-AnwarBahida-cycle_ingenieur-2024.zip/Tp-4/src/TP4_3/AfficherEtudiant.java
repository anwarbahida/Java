package TP4_3;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AfficherEtudiant {
    private JPanel panel;
    private JRadioButton TriCNE, TriPrenom, TriDate_Naiss;
    private JButton Actualisation;

    // Base de données
    private static final String DB_URL = "jdbc:mysql://localhost:3306/dbGestion";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public AfficherEtudiant() {
        panel = new JPanel();
        panel.setLayout(null);

        // Titre
        JLabel lblTitre = new JLabel("Affichage d'Etudiants", SwingConstants.CENTER);
        lblTitre.setBounds(0, 0, 900, 35);
        lblTitre.setOpaque(true);
        lblTitre.setBackground(Color.GREEN);
        lblTitre.setForeground(Color.WHITE);
        lblTitre.setFont(new Font("Consolas", Font.BOLD, 20));
        panel.add(lblTitre);

        JLabel lblGenre = new JLabel("Trier par :");
        lblGenre.setBounds(30, 50, 100, 25);
        panel.add(lblGenre);

        TriCNE = new JRadioButton("CNE");
        TriCNE.setBounds(180, 50, 80, 25);

        TriPrenom = new JRadioButton("Nom");
        TriPrenom.setBounds(320, 50, 80, 25);

        TriDate_Naiss = new JRadioButton("DateNaiss");
        TriDate_Naiss.setBounds(460, 50, 120, 25);

        ButtonGroup groupGenre = new ButtonGroup();
        groupGenre.add(TriCNE);
        groupGenre.add(TriPrenom);
        groupGenre.add(TriDate_Naiss);

        panel.add(TriCNE);
        panel.add(TriPrenom);
        panel.add(TriDate_Naiss);

        Actualisation = new JButton("Actualisation");
        Actualisation.setBounds(650, 50, 150, 36);
        Actualisation.setBackground(new Color(10, 130, 160));
        Actualisation.setForeground(Color.WHITE);

        panel.add(Actualisation);

        // Tableau
        String[] columnNames = new String[] { "CNE", "Nom", "Prénom", "DateNaiss", "Email", "Genre", "Pays", "Diplome" };
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        JTable tableau = new JTable(tableModel);
        JScrollPane sp = new JScrollPane(tableau);
        sp.setSize(800, 300);
        sp.setLocation(40, 140);
        panel.add(sp);

        // Charger les données dans le tableau
        chargerDonnees(tableModel, "");

        // Action pour le bouton d'actualisation
        Actualisation.addActionListener(e -> {
            String orderBy = ""; // Critère de tri

            if (TriCNE.isSelected()) {
                orderBy = "CNE";
            } else if (TriPrenom.isSelected()) {
                orderBy = "nom";
            } else if (TriDate_Naiss.isSelected()) {
                orderBy = "date_naissance";
            }

            chargerDonnees(tableModel, orderBy);
        });
    }

    private void chargerDonnees(DefaultTableModel tableModel, String orderBy) {
        // Effacer les données existantes dans le tableau
        tableModel.setRowCount(0);

        // Requête SQL avec tri si nécessaire
        String query = "SELECT * FROM etudiants";
        if (!orderBy.isEmpty()) {
            query += " ORDER BY " + orderBy;
        }

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Parcourir les résultats et ajouter les lignes au tableau
            while (resultSet.next()) {
                String cne = resultSet.getString("CNE");
                String nom = resultSet.getString("nom");
                String prenom = resultSet.getString("prenom");
                String dateNaiss = resultSet.getString("date_naissance");
                String email = resultSet.getString("email");
                String genre = resultSet.getString("genre");
                String pays = resultSet.getString("pays");
                String diplome = resultSet.getString("diplomes");

                tableModel.addRow(new Object[] { cne, nom, prenom, dateNaiss, email, genre, pays, diplome });
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(panel, "Erreur lors du chargement des données : " + ex.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public JPanel getPanel() {
        return panel;
    }
}
