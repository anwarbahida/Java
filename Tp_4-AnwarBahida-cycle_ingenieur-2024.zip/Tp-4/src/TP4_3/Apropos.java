package TP4_3;
import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class Apropos {

    private JPanel panel;

    public Apropos() {
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Disposition verticale pour tout le panneau

        // Créer une étiquette pour afficher l'image
        JLabel imageLabel = new JLabel();
        try {
            // Charger l'image depuis le dossier "images" (assurez-vous que l'image Anwar.jpg est dans le répertoire approprié)
            URL imageUrl = getClass().getResource("Anwar.jpg");
            if (imageUrl != null) {
                ImageIcon imageIcon = new ImageIcon(imageUrl);
                // Redimensionner l'image à 220px x 220px
                Image image = imageIcon.getImage().getScaledInstance(220, 220, Image.SCALE_SMOOTH);
                imageLabel.setIcon(new ImageIcon(image));
            }
        } catch (Exception e) {
            imageLabel.setText("Image non disponible");
        }

        // Créer un panneau avec des informations textuelles
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

        JLabel versionLabel = new JLabel("Version: 1.0");
        JLabel devLabel = new JLabel("Développeur: Anwar Bahida");
        JLabel emailLabel = new JLabel("Email: AnwarBahida@gmail.com");

        infoPanel.add(versionLabel);
        infoPanel.add(devLabel);
        infoPanel.add(emailLabel);

        // Ajouter l'image et les informations dans le panneau principal
        panel.add(imageLabel); // Ajouter l'image en haut
        panel.add(Box.createRigidArea(new Dimension(0, 10))); // Ajouter un espace vertical entre l'image et les informations
        panel.add(infoPanel);  // Ajouter les informations en dessous

        // Assurez-vous que le panneau est bien redimensionné et centré
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    // Méthode pour obtenir le panneau de l'application
    public JPanel getPanel() {
        return panel;
    }
}
