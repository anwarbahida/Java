package TP4_3;

import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class Principale{

    JFrame fen;
    JMenuBar barreMenue;
    JMenu menu1, menu2, menu3;
    JMenuItem menu1opt1, menu1opt2, menu2opt1, menu2opt2, menu2opt3, menu3opt1;
    JPanel mainPanel; // Panneau principal pour afficher le contenu

    public Principale()  {

        fen = new JFrame("Application td4 ");
        fen.setSize(900, 750);
        fen.setLocationRelativeTo(null);
        fen.setLayout(new BorderLayout()); // Utilisation de BorderLayout pour gérer les panneaux
        fen.setResizable(false);
        
     // Initialisation du panneau principal
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        barreMenue = new JMenuBar();

        menu1 = new JMenu("Fichier");
        menu2 = new JMenu("Affichage");
        menu3 = new JMenu("Aide");

        menu1opt1 = new JMenuItem("Enregistrer");
        menu1opt2 = new JMenuItem("Quitter");
        menu2opt1 = new JMenuItem("Page_1");
        menu2opt2 = new JMenuItem("Page_2");
        menu2opt3 = new JMenuItem("Page_3");
        menu3opt1 = new JMenuItem("A propos");

        menu1.add(menu1opt1);
        menu1.addSeparator();
        menu1.add(menu1opt2);

        menu2.add(menu2opt1);
        menu2.addSeparator();
        menu2.add(menu2opt2);
        menu2.addSeparator();
        menu2.add(menu2opt3);
        menu3.add(menu3opt1);

        barreMenue.add(menu1);
        barreMenue.add(menu2);
        barreMenue.add(menu3);

        fen.setJMenuBar(barreMenue);
        
     // Titre
        JLabel lblTitre = new JLabel("Gestion des Etudiants", SwingConstants.CENTER);
        lblTitre.setBounds(0, 0, 900, 35);
        lblTitre.setOpaque(true); // Permet de définir un fond
        lblTitre.setBackground(Color.GREEN); // Couleur de fond en vert
        lblTitre.setForeground(Color.WHITE); // Couleur du texte en blanc (facultatif pour le contraste)
        lblTitre.setFont(new Font("Consolas", Font.BOLD, 20)); // Police en gras et taille 20
        mainPanel.add(lblTitre);
        
     // Créer une étiquette pour afficher l'image
        JLabel imageAcceuil = new JLabel();
        imageAcceuil.setBounds(40, 40, 900, 35);
        
        try {
            // Charger l'image depuis le dossier "images" (assurez-vous que l'image Anwar.jpg est dans le répertoire approprié)
            URL imageUrl = getClass().getResource("B.png");
            if (imageUrl != null) {
                ImageIcon imageIcon = new ImageIcon(imageUrl);
                
                Image image = imageIcon.getImage().getScaledInstance(900, 600, Image.SCALE_SMOOTH);
                imageAcceuil.setIcon(new ImageIcon(image));
            }
        } catch (Exception e) {
            imageAcceuil.setText("Image non disponible");
        }
        mainPanel.add(imageAcceuil);
        
        fen.add(mainPanel, BorderLayout.CENTER);
        
        // Action pour quitter l'application
        menu1opt2.addActionListener(e -> System.exit(0));
        
        // Action pour afficher le formulaire AjouterEtudiant
        menu2opt1.addActionListener(e -> Page());
        
       // Action pour afficher le formulaire AjouterEtudiant
        menu2opt2.addActionListener(e -> AjouterEtudiant());
        
        // Action pour afficherEudiant
        menu2opt3.addActionListener(e -> afficherEtudiant());
        
        // Action pour A Propose
        menu3opt1.addActionListener(e -> AfficheApropos());

        fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fen.setVisible(true);
     }
    
	 private void AfficheApropos() {
		 
		 Apropos Apropos = new Apropos();
	     mainPanel.removeAll(); // Efface le contenu existant
	     mainPanel.add(Apropos.getPanel(), BorderLayout.CENTER); // Ajoute le formulaire
	     mainPanel.revalidate(); // Rafraîchit l'interface
	     mainPanel.repaint(); // Redessine le panneau
		 
		}
	 
	 private void Page() {
		    // Créer ou afficher le contenu de Page_1 dans le même panel
		    JPanel page1Panel = new JPanel(); // Exemple de panneau pour la page 1
		    page1Panel.setLayout(new BorderLayout());

		 // Titre
	        JLabel lblTitre = new JLabel("Gestion des Etudiants", SwingConstants.CENTER);
	        lblTitre.setBounds(0, 0, 900, 35);
	        lblTitre.setOpaque(true); // Permet de définir un fond
	        lblTitre.setBackground(Color.GREEN); // Couleur de fond en vert
	        lblTitre.setForeground(Color.WHITE); // Couleur du texte en blanc (facultatif pour le contraste)
	        lblTitre.setFont(new Font("Consolas", Font.BOLD, 20)); // Police en gras et taille 20
	        page1Panel.add(lblTitre);
	        
	     // Créer une étiquette pour afficher l'image
	        JLabel imageAcceuil = new JLabel();
	        imageAcceuil.setBounds(40, 40, 900, 35);
	        
	        try {
	            // Charger l'image depuis le dossier "images" (assurez-vous que l'image Anwar.jpg est dans le répertoire approprié)
	            URL imageUrl = getClass().getResource("B.png");
	            if (imageUrl != null) {
	                ImageIcon imageIcon = new ImageIcon(imageUrl);
	                
	                Image image = imageIcon.getImage().getScaledInstance(900, 600, Image.SCALE_SMOOTH);
	                imageAcceuil.setIcon(new ImageIcon(image));
	            }
	        } catch (Exception e) {
	            imageAcceuil.setText("Image non disponible");
	        }
	        page1Panel.add(imageAcceuil);

		    // Supprimer l'ancien contenu et ajouter le nouveau
		    mainPanel.removeAll(); // Efface le contenu existant
		    mainPanel.add(page1Panel, BorderLayout.CENTER); // Ajoute le contenu de Page_1
		    mainPanel.revalidate(); // Rafraîchit l'interface
		    mainPanel.repaint(); // Redessine le panneau
		}

	private Component getPanel() {
			return mainPanel;
		}

	// Méthode pour afficher le tableau d'Etudiant
    private void afficherEtudiant() {
        AfficherEtudiant afficherEtudiant = new AfficherEtudiant();
        mainPanel.removeAll(); // Efface le contenu existant
        mainPanel.add(afficherEtudiant.getPanel()); // Ajoute le formulaire
        mainPanel.revalidate(); // Rafraîchit l'interface
        mainPanel.repaint(); // Redessine le panneau
    }

    // Méthode pour afficher le formulaire AjouterEtudiant
    private void AjouterEtudiant() {
        AjouterEtudiant ajouterEtudiant = new AjouterEtudiant();
        mainPanel.removeAll(); // Efface le contenu existant
        mainPanel.add(ajouterEtudiant.getPanel(), BorderLayout.CENTER); // Ajoute le formulaire
        mainPanel.revalidate(); // Rafraîchit l'interface
        mainPanel.repaint(); // Redessine le panneau
    }
    
    public static void main(String args []) {
    	new Principale();
    }
    
}