package TP4_1;

import TP4_2.BarreCouleur;
import TP4_3.Principale;

public class main {
	public static void main(String args []) {
		//new Saisit();
		//new BarreCouleur();
		new Principale();
	}

}
