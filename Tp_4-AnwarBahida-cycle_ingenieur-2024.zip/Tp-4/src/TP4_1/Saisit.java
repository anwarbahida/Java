package TP4_1;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Saisit extends JFrame implements ActionListener {
	
	JFrame fen;
	JLabel l_cne,l_nom,l_prenom,l_sexe,l_ville,l_email,l_lang;
	
	JTextField t_cne,t_nom,t_prenom,t_email;
	JRadioButton homme,femme;
	JComboBox ville;
	JCheckBox ar,fr,en,Am;
	JButton b_annuler,b_envoyer;
	
	public Saisit() {
		demarrer();
	}

	public void demarrer() {
	    fen = new JFrame("Application");
	    fen.setSize(800, 600);
	    fen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ajout pour fermer correctement
	    fen.setLayout(null);
	    fen.setResizable(false);

	    // Création du JPanel et définition du fond
	    JPanel pan = new JPanel();
	    pan.setSize(800, 600);
	    pan.setLayout(null);
	    pan.setBackground(new Color(70, 170, 200)); // Couleur de fond pour le JPanel

	    // Labels
	    l_cne = new JLabel("CNE");
	    l_cne.setBounds(200, 100, 150, 20);
	    pan.add(l_cne);

	    l_nom = new JLabel("NOM");
	    l_nom.setBounds(200, 140, 150, 20);
	    pan.add(l_nom);

	    l_prenom = new JLabel("PRENOM");
	    l_prenom.setBounds(200, 180, 150, 20);
	    pan.add(l_prenom);

	    l_sexe = new JLabel("SEXE");
	    l_sexe.setBounds(200, 220, 150, 20);
	    pan.add(l_sexe);

	    l_ville = new JLabel("VILLE");
	    l_ville.setBounds(200, 260, 150, 20);
	    pan.add(l_ville);

	    l_email = new JLabel("EMAIL");
	    l_email.setBounds(200, 300, 150, 20);
	    pan.add(l_email);

	    l_lang = new JLabel("LANGUE");
	    l_lang.setBounds(200, 340, 150, 20);
	    pan.add(l_lang);

	    // Text Fields
	    t_cne = new JTextField();
	    t_cne.setBounds(360, 100, 200, 30);
	    pan.add(t_cne);

	    t_nom = new JTextField();
	    t_nom.setBounds(360, 140, 200, 30);
	    pan.add(t_nom);

	    t_prenom = new JTextField();
	    t_prenom.setBounds(360, 180, 200, 30);
	    pan.add(t_prenom);

	    t_email = new JTextField();
	    t_email.setBounds(360, 300, 200, 30);
	    pan.add(t_email);

	    // Radio Buttons
	    homme = new JRadioButton("Homme");
	    homme.setBounds(360, 220, 100, 30);
	    pan.add(homme);

	    femme = new JRadioButton("Femme");
	    femme.setBounds(460, 220, 100, 30);
	    pan.add(femme);

	    ButtonGroup gr1 = new ButtonGroup();
	    gr1.add(homme);
	    gr1.add(femme);

	    // ComboBox
	    String[] listville = {"Errachidia", "Tinghir", "Klaa Mgouna", "Rich", "Midelt"};
	    ville = new JComboBox<>(listville);
	    ville.addItem("Mrzouga");
	    ville.setBounds(360, 260, 200, 30);
	    pan.add(ville);

	    // Checkboxes
	    ar = new JCheckBox("AR");
	    ar.setBounds(360, 340, 50, 30);
	    pan.add(ar);

	    fr = new JCheckBox("FR");
	    fr.setBounds(410, 340, 50, 30);
	    pan.add(fr);

	    en = new JCheckBox("EN");
	    en.setBounds(460, 340, 50, 30);
	    pan.add(en);

	    Am = new JCheckBox("AMZ");
	    Am.setBounds(510, 340, 50, 30);
	    pan.add(Am);

	    // Buttons
	    b_annuler = new JButton("Annuler");
	    b_annuler.setBounds(300, 400, 90, 50);
	    pan.add(b_annuler);
	    b_annuler.addActionListener(this);

	    b_envoyer = new JButton("Envoyer");
	    b_envoyer.setBounds(440, 400, 90, 50);
	    pan.add(b_envoyer);
	    b_envoyer.addActionListener(this);

	    fen.setContentPane(pan);
	    fen.setVisible(true);
	}


    @Override
    public void actionPerformed(ActionEvent env) {
        Object source = env.getSource();

        if (source.equals(b_annuler)) {
            // Clear all fields and selections
            t_cne.setText("");
            t_nom.setText("");
            t_prenom.setText("");
            t_email.setText("");
            homme.setSelected(false);
            femme.setSelected(false);
            ar.setSelected(false);
            fr.setSelected(false);
            en.setSelected(false);
            Am.setSelected(false);
            ville.setSelectedIndex(0);
        } else if (source.equals(b_envoyer)) {
            
            String sexe = homme.isSelected() ? "Homme" : (femme.isSelected() ? "Femme" : "Non spécifié");
            String langues = "";
            if (ar.isSelected()) langues += "AR ";
            if (fr.isSelected()) langues += "FR ";
            if (en.isSelected()) langues += "EN ";
            if (Am.isSelected()) langues += "AMZ ";

            System.out.println("CNE : " + t_cne.getText());
            System.out.println("Nom : " + t_nom.getText());
            System.out.println("Prenom : " + t_prenom.getText());
            System.out.println("Email : " + t_email.getText());
            System.out.println("Sexe : " + sexe);
            System.out.println("Ville : " + ville.getSelectedItem());
            System.out.println("Langues : " + langues.trim());
            

            // Example of saving data (replace with actual implementation)
            String cheminActuel = System.getProperty("user.dir");
            AuthentificationInterface auth = new AuthentificationInterface(cheminActuel+"\\fichier1.data");
            auth.Enregistrer(t_cne.getText(), t_nom.getText(),  t_prenom.getText(), t_email.getText(), sexe , ville.getSelectedItem(), langues);
   
            auth.afficherFormatte();
            auth.lireFichier();
            auth.afficherFormatte();
            
            
	        }
        
	    }
}

