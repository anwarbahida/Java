package BarreColeur;

import java.awt.Color;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class coleur implements AdjustmentListener, ChangeListener {
	JFrame fen;
	JLabel lblRouge,lblVert,lblBlue,lblCouChoi,lblGlissiere;
	JScrollBar barRouge,barVert,barBlue;
	JSlider Glissiere ;
	JTextField txtRouge,txtVert,txtBlue ;
	
	int ValeurGlissiere =100;
	
   public coleur(){
	   demarrer();
   }
   
   public void demarrer() {
	   
	   fen = new JFrame("Test des Barres et Conteneur ");
       fen.setSize(700, 450);
       fen.setLayout(null);
       fen.setResizable(false);
       fen.setLocationRelativeTo(null);
       ImageIcon icon = new ImageIcon(getClass().getResource("./images/BarreColeur.ico"));
       fen.setIconImage(icon.getImage());
	   
       //Les barres des Couleurs
	   barRouge = new JScrollBar(JScrollBar.HORIZONTAL);
	   barRouge.setMaximum(265);
	   barRouge.setBounds(100,100,200,30);
	   barRouge.setBackground(Color.RED);
	   barRouge.setOpaque(true);
	   barRouge.addAdjustmentListener(this);
	   fen.add(barRouge);
	   
	   barVert = new JScrollBar(JScrollBar.HORIZONTAL);
	   barVert.setMaximum(265);
	   barVert.setBounds(100,140,200,30);
	   barVert.setBackground(Color.GREEN);
	   barVert.addAdjustmentListener(this);
	   barVert.setOpaque(true);
	   fen.add(barVert);
	   
	   barBlue = new JScrollBar(JScrollBar.HORIZONTAL);
	   barBlue.setBounds(100,180,200,30);
	   barBlue.setMaximum(265);
	   barBlue.setBackground(Color.BLUE);
	   barBlue.addAdjustmentListener(this);
	   barBlue.setOpaque(true);
	   fen.add(barBlue);
	   
	   //Valeur de Couleur
	   txtRouge=new JTextField("0");
	   txtRouge.setBounds(310,100,30,30);
	   fen.add(txtRouge);
	   
	   txtVert=new JTextField("0");
	   txtVert.setBounds(310,140,30,30);
	   fen.add(txtVert);
	   
	   txtBlue=new JTextField("0");
	   txtBlue.setBounds(310,180,30,30);
	   fen.add(txtBlue);
	   
	   
	   //Labels des couleur 
	   lblRouge =new JLabel();
	   lblRouge.setBounds(60,100,30,30);
	   lblRouge.setBackground(Color.RED);
	   lblRouge.setOpaque(true);
	   fen.add(lblRouge);
	   
	   lblVert =new JLabel();
	   lblVert.setBounds(60,140,30,30);
	   lblVert.setBackground(Color.GREEN);
	   lblVert.setOpaque(true);
	   fen.add(lblVert);
	   
	   lblBlue =new JLabel();
	   lblBlue.setBounds(60,180,30,30);
	   lblBlue.setBackground(Color.BLUE);
	   lblBlue.setOpaque(true);
	   fen.add(lblBlue);
	   
	   //Couleur Choisi
	   lblCouChoi=new JLabel("                Couleur Choisit");
	   lblCouChoi.setBounds(450, 100, 200, 110);
	   lblCouChoi.setBackground(new Color(0,0,0));
	   lblCouChoi.setOpaque(true);
	   fen.add(lblCouChoi);
	    
	   
	   // Glissiere 
	   Glissiere=new JSlider(0,200);
	   Glissiere.setBounds(130, 300, 300, 40);
	   Glissiere.setMajorTickSpacing(20);
	   Glissiere.setMinorTickSpacing(5);
	   Glissiere.setPaintLabels(true);
	   Glissiere.setPaintTicks(true);
	   Glissiere.addChangeListener(this);;
	   fen.add(Glissiere);
	   
	   //Label de Glissiere 
	   lblGlissiere= new JLabel("La valeur de Glissiere est : " + ValeurGlissiere);
	   lblGlissiere.setBounds(200, 350, 300, 40);
	   fen.add(lblGlissiere);
	   
	   //affichage de fenetre 
	   fen.setVisible(true);
   }

	@Override
	public void adjustmentValueChanged(AdjustmentEvent env) {
		// TODO Auto-generated method stub
		Object source = env.getSource();
		
		if (source.equals(barRouge) || source.equals(barVert) || source.equals(barBlue)) {
			
			int Rouge = barRouge.getValue();
			int Vert = barVert.getValue();
			int Blue = barBlue.getValue();
			
			txtRouge.setText(""+Rouge);
			txtVert.setText(""+Vert);
			txtBlue.setText(""+Blue);
			
			lblCouChoi.setBackground(new Color(Rouge,Vert,Blue));
			
		}
	}
	@Override
    public void stateChanged(ChangeEvent e) {
        // Mise à jour de la valeur du slider
        int valeur = Glissiere.getValue();
        lblGlissiere.setText("La valeur de Glissiere est : " + valeur);
    }
	
	public static void main(String[] args ) {
		new coleur();
	}
}

	
	

