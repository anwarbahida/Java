package Exercice1;

public class Test {
    public static void main(String[] args) {
        // Initialisation de l'objet Authentification avec le chemin du fichier
    	String cheminActuel = System.getProperty("user.dir");
        Authentification auth = new Authentification(cheminActuel+"\\fichier.data");
        
        // Tester la méthode Enregistrer
        System.out.println("=== Test de la méthode Enregistrer ===");
        auth.Enregistrer("Amdouni", "Ali", "25-10-2000", "Homme", "Licence", "Rabat", "bnali", "admin123");
        auth.Enregistrer("Ballouki", "Hassan", "02-03-1999", "Homme", "Master", "Errachidia", "bball", "1236");
        auth.Enregistrer("Sellami", "Aicha", "06-05-2003", "Femme", "BTS", "Oujda", "salai", "ma@123");

        // Tester la méthode lireFichier
        System.out.println("\n=== Test de la méthode lireFichier ===");
        auth.lireFichier();

        // Tester la méthode afficherFormatte
        System.out.println("\n=== Test de la méthode afficherFormatte ===");
        auth.afficherFormatte();

        // Tester la méthode Authentifier
        System.out.println("\n=== Test de la méthode Authentifier ===");
        boolean result1 = auth.Authentifier("bnali", "admin123"); // Doit retourner true
        boolean result2 = auth.Authentifier("bball", "wrongpass"); // Doit retourner false
        
        System.out.println("Authentification avec 'bnali' et 'admin123' : " + (result1 ? "Réussi" : "Échoué"));
        System.out.println("Authentification avec 'bball' et 'wrongpass' : " + (result2 ? "Réussi" : "Échoué"));
    }
}
