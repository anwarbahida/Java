package Exercice1;

import java.io.*;
import java.util.StringTokenizer;

public class Authentification {
    private String data;

    public Authentification() {
        this.data = "fichier.data";
    }

    public Authentification(String data) {
        this.data = data;
    }

    public void Enregistrer(String nom, String prenom, String dateNaissance, String genre, 
                            String diplome, String ville, String login, String motPasse) {
        try (FileWriter writer = new FileWriter(data)) {
            String ligne = nom + "#" + prenom + "#" + dateNaissance + "#" + genre + "#" 
                         + diplome + "#" + ville + "#" + login + "#" + motPasse + "\n";
            writer.write(ligne);
            System.out.println("Enregistrement réussi !");
        } catch (IOException e) {
            System.out.println("Erreur lors de l'enregistrement : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void lireFichier() {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                System.out.println(ligne);
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void afficherFormatte() {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(ligne, "#");
                if (tokenizer.countTokens() == 8) { 
                    System.out.println("Nom : " + tokenizer.nextToken() + ", Prenom : " + tokenizer.nextToken() +
                                       ", Date de naissance : " + tokenizer.nextToken() + ", Genre : " + tokenizer.nextToken() +
                                       ", Diplome : " + tokenizer.nextToken() + ", Ville : " + tokenizer.nextToken() +
                                       ", Login : " + tokenizer.nextToken() + ", Password : " + tokenizer.nextToken());
                } else {
                    System.out.println("Enregistrement mal formaté : " + ligne);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture : " + e.getMessage());
            e.printStackTrace();
        }
    }


    public boolean Authentifier(String log, String motPasse) {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(ligne, "#");
                if (tokenizer.countTokens() == 8) { 
                    tokenizer.nextToken(); // nom
                    tokenizer.nextToken(); // prenom
                    tokenizer.nextToken(); // date de naissance
                    tokenizer.nextToken(); // genre
                    tokenizer.nextToken(); // diplome
                    tokenizer.nextToken(); // ville
                    String login = tokenizer.nextToken();
                    String password = tokenizer.nextToken();
                    
                    if (login.equals(log) && password.equals(motPasse)) {
                        return true;
                    }
                } else {
                    System.out.println("Ligne mal formatée ignorée : " + ligne);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de l'authentification : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

}
