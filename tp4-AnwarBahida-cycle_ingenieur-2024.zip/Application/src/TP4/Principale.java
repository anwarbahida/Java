package TP4;

public class Principale {
	public static void main(String args []) {
		Saisit s=new Saisit();
	}

}
