package TP4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

public class Authentification {
	private String data;

    public Authentification() {
        this.data = "fichier.data";
    }

    public Authentification(String data) {
        this.data = data;
    }

    public void Enregistrer(String cne,String nom, String prenom, String Email, String sexe, Object object , String lang) {
        try (FileWriter writer = new FileWriter(data)) {
            String ligne = cne + "#" +nom + "#"+ prenom + "#" + Email + "#" + sexe + "#" + object +"#" + lang +"\n";
            writer.write(ligne);
            System.out.println("Enregistrement réussi !");
        } catch (IOException e) {
            System.out.println("Erreur lors de l'enregistrement : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void lireFichier() {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                System.out.println(ligne);
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void afficherFormatte() {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(ligne, "#");
                if (tokenizer.countTokens() == 7) { // Vérifie qu'il y a bien 8 champs
                    System.out.println("CNE : " + tokenizer.nextToken() + "nom : " + tokenizer.nextToken()+", Prenom : " + tokenizer.nextToken() +
                                       ", Email : " + tokenizer.nextToken() + ", sexe : " + tokenizer.nextToken() +
                                       ", Ville : " + tokenizer.nextToken() + ", Langue : " + tokenizer.nextToken());
                } else {
                    System.out.println("Enregistrement mal formaté : " + ligne);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture : " + e.getMessage());
            e.printStackTrace();
        }
    }


    public boolean Authentifier(String CNE, String NOM) {
        try (BufferedReader reader = new BufferedReader(new FileReader(data))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(ligne, "#");
                if (tokenizer.countTokens() == 7) { 
                	String cne=tokenizer.nextToken();
                	String nom=tokenizer.nextToken();
                    tokenizer.nextToken(); 
                    tokenizer.nextToken(); 
                    tokenizer.nextToken(); 
                    tokenizer.nextToken(); 
                    tokenizer.nextToken(); 
                    tokenizer.nextToken(); 
    
                    
                    if (cne.equals(CNE) && nom.equals(NOM)) {
                        return true;
                    }
                } else {
                    System.out.println("Ligne mal formatée ignorée : " + ligne);
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de l'authentification : " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}
